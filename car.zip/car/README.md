# car — 二面项目工程（可直接开写 + 已配好编译/烧录）

这是一个**最小骨架**：只包含官方 STM32F4 HAL/CMSIS 库、一个点灯 `main.c`、编译和烧录配置。
**没有任何业务代码**，你的东西全部写在 `User/` 里。

## 打开方式

VS Code 打开本文件夹：`D:\Code Project\VScode\stm32\projects\car`（不要打开上级目录）。
首次打开会提示装推荐扩展（C/C++、CMake Tools、Cortex-Debug 等，已装过就跳过）。

## 编译

- VS Code：`Ctrl+Shift+B`（默认任务）
- 终端：
  ```powershell
  C:\Users\37943\AppData\Local\Microsoft\WinGet\Packages\Kitware.CMake_Microsoft.Winget.Source_8wekyb3d8bbwe\cmake-4.4.4-windows-x86_64\bin\cmake.exe --preset debug -S .
  C:\Users\37943\AppData\Local\Microsoft\WinGet\Packages\Kitware.CMake_Microsoft.Winget.Source_8wekyb3d8bbwe\cmake-4.4.4-windows-x86_64\bin\cmake.exe --build build/debug
  ```
产物：`build/debug/car.elf | car.hex | car.bin`

## 烧录（接 ST-LINK：SWDIO / SWCLK / GND / 3V3）

- VS Code 任务：`STM32: flash (ST-LINK)`
- 终端：
  ```powershell
  C:\Users\37943\AppData\Local\stm32cube\bundles\programmer\2.23.0\bin\STM32_Programmer_CLI.exe -c port=SWD mode=UR reset=HWrst -w build/debug/car.hex -v -rst
  ```
- 不想敲命令：直接双击项目根目录的 `flash.bat`（自动增量编译 + 烧录；桌面已有快捷方式，双击即可）
- 调试：`F5` → `STM32: 真机调试 (ST-LINK + OpenOCD)`

## 代码写在哪里

| 位置 | 放什么 |
| --- | --- |
| `User/Src/` + `User/Inc/` | **你的业务代码**（电机、IMU、循迹、PID、串口协议……）；新增 `.c` 后重新 Configure 一次（`Ctrl+Shift+B` 会顺带 configure） |
| `Core/Src/main.c` | 启动流程：`HAL_Init` → 时钟 → GPIO → `user_app_init()` → 主循环里调 `user_app_loop()` |
| `Core/Inc/main.h` | LED 引脚宏等全局定义 |
| `Core/Src/stm32f4xx_hal_msp.c` | HAL 底层时钟/引脚回调（一般不用动） |
| `Drivers/` | 官方 HAL/CMSIS，**不要改** |
| `cmake/` | 工具链文件 + 链接脚本（512K Flash/128K RAM） |

## 换板子 / 换引脚

1. 换芯片系列：改 `CMakeLists.txt` 里的 `STM32F411xE` 宏、启动文件、链接脚本，并把 `-mcpu` 改成对应内核；
2. 换引脚：改 `main.c` 里 `MX_GPIO_Init()`，或按你的模块加初始化函数；
3. 默认 LED = PA5（NUCLEO-F411RE 板载 LD2）。板子不同就改 `main.h` 的 `LED_Pin`。

## 说明

- 目前只验证到**编译通过**；烧录链路需要接上 ST-LINK 和板子实测（驱动已装，见环境说明）。
- 时钟默认用内部 HSI 16MHz，简单够用；需要 100MHz 时改 `SystemClock_Config()`（HSE 8MHz + PLL）。
- 串口 `printf` 需要自己加串口初始化 + `_write` 重定向；`printf` 也可以直接用 `HAL_UART_Transmit` 替代。
- 需要新增 HAL 外设（CAN/USB/SPI 等）时，把对应 `Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal_xxx.c` 加进 `CMakeLists.txt` 的 `HAL_SOURCES`。

## 团队共享（Git）

本目录已初始化为 Git 仓库（分支 `main`）。远程仓库地址：`<待填：GitHub 仓库 URL>`。

### 队友第一次使用

```bash
git clone <仓库地址>
cd car
# 装好工具链后，按下面表格改自己电脑上的路径，然后 Ctrl+Shift+B 编译
```

### 队友要改的路径（每台电脑工具安装位置不同）

| 文件 | 要改的项 |
| --- | --- |
| `.vscode/settings.json` | `cmake.cmakePath`、`C_Cpp.default.compilerPath`、`cortex-debug.openocdPath`、`cortex-debug.armToolchainPath` |
| `CMakePresets.json` | `cacheVariables.CMAKE_MAKE_PROGRAM`（`ninja.exe` 路径；或删掉这行，把 ninja 加进 PATH） |
| `cmake/toolchain-arm-none-eabi.cmake` | `ARM_TOOLCHAIN_PATH` 默认值（arm-none-eabi-gcc.exe 所在目录） |
| `.vscode/tasks.json` | 四个任务里的 `cmake.exe`、`STM32_Programmer_CLI.exe`、`arm-none-eabi-size.exe` 路径 |

工具链安装（Windows）：Arm GNU Toolchain 14.x、CMake ≥ 3.22、Ninja、VS Code + 推荐扩展（打开项目会提示）。

### 日常协作流程

1. 开工前先 `git pull --rebase`
2. 业务代码写在 `User/Src`、`User/Inc`（新增 `.c` 会自动加入编译）
3. **本地编译通过后**再 `git add -A && git commit -m "说明"`
4. `git push`（推送慢可以重试，别用 `--force` 推 `main`）
5. 冲突处理：`git pull --rebase` → 解决冲突 → `git add` → `git rebase --continue`

### 约定

- `main` 分支必须保持**随时可编译、可烧录**；
- 换引脚/换芯片/大改外设，单独开分支（如 `feature/pinout-改版`），合并前通知队友；
- 不要提交 `build/`、`*.elf`、`*.hex`、`*.bin`、`*.map`（`.gitignore` 已处理）；
- 每天收工前提交一个稳定版本：`git tag v0.1-日期`。
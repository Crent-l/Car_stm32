/*
 * 最小可运行模板（点灯 + 调用 User 区代码）
 * ------------------------------------------------------------------
 * - 外设初始化：在 MX_GPIO_Init() 里加 GPIO，其它外设参考 HAL 例程自己加，
 *   或直接打开 CubeMX 生成后把代码搬过来。
 * - 业务代码：写到 User/Src/user_app.c（user_app_init / user_app_loop）。
 * - 编译：Ctrl+Shift+B（VS Code）或 cmake --build build/debug
 * - 烧录：任务 "STM32: flash (ST-LINK)"
 */
#include "main.h"
#include "user_app.h"

void Error_Handler(void)
{
    __disable_irq();
    for (;;) { }
}

/* 先用内部 HSI 16MHz 跑起来；项目需要更高主频时再改成 HSE + PLL */
static void SystemClock_Config(void)
{
    RCC_OscInitTypeDef osc = {0};
    RCC_ClkInitTypeDef clk = {0};

    osc.OscillatorType      = RCC_OSCILLATORTYPE_HSI;
    osc.HSIState            = RCC_HSI_ON;
    osc.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
    osc.PLL.PLLState        = RCC_PLL_NONE;
    if (HAL_RCC_OscConfig(&osc) != HAL_OK) {
        Error_Handler();
    }

    clk.ClockType      = RCC_CLOCKTYPE_HCLK | RCC_CLOCKTYPE_SYSCLK |
                         RCC_CLOCKTYPE_PCLK1 | RCC_CLOCKTYPE_PCLK2;
    clk.SYSCLKSource   = RCC_SYSCLKSOURCE_HSI;
    clk.AHBCLKDivider  = RCC_SYSCLK_DIV1;
    clk.APB1CLKDivider = RCC_HCLK_DIV1;
    clk.APB2CLKDivider = RCC_HCLK_DIV1;
    if (HAL_RCC_ClockConfig(&clk, FLASH_LATENCY_0) != HAL_OK) {
        Error_Handler();
    }
}

static void MX_GPIO_Init(void)
{
    GPIO_InitTypeDef io = {0};

    __HAL_RCC_GPIOA_CLK_ENABLE();

    HAL_GPIO_WritePin(LED_GPIO_Port, LED_Pin, GPIO_PIN_RESET);
    io.Pin   = LED_Pin;
    io.Mode  = GPIO_MODE_OUTPUT_PP;
    io.Pull  = GPIO_NOPULL;
    io.Speed = GPIO_SPEED_FREQ_LOW;
    HAL_GPIO_Init(LED_GPIO_Port, &io);
}

int main(void)
{
    HAL_Init();
    SystemClock_Config();
    MX_GPIO_Init();

    user_app_init();

    uint32_t last_led_ms = 0U;
    for (;;) {
        uint32_t now = HAL_GetTick();
        if (now - last_led_ms >= 500U) {       /* 心跳灯：确认程序在跑 */
            last_led_ms = now;
            HAL_GPIO_TogglePin(LED_GPIO_Port, LED_Pin);
        }
        user_app_loop();                        /* ← 你的主逻辑在这里被调用 */
    }
}

#include "main.h"

void NMI_Handler(void)        { for (;;) { } }
void HardFault_Handler(void)  { for (;;) { } }
void MemManage_Handler(void)  { for (;;) { } }
void BusFault_Handler(void)   { for (;;) { } }
void UsageFault_Handler(void) { for (;;) { } }
void SVC_Handler(void)        { for (;;) { } }
void DebugMon_Handler(void)   { for (;;) { } }
void PendSV_Handler(void)     { for (;;) { } }

void SysTick_Handler(void)
{
    HAL_IncTick();
}

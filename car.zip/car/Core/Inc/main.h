#ifndef MAIN_H
#define MAIN_H

#ifdef __cplusplus
extern "C" {
#endif

#include "stm32f4xx_hal.h"
#include <stdint.h>

/* 板载 LED（NUCLEO-F411RE 为 PA5；换板子改这两行） */
#define LED_GPIO_Port GPIOA
#define LED_Pin       GPIO_PIN_5

void Error_Handler(void);

#ifdef __cplusplus
}
#endif

#endif /* MAIN_H */

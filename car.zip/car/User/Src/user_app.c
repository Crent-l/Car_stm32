/*
 * 你的业务代码写在这里（这个文件不会被自动生成覆盖）。
 * 思路：初始化放 user_app_init()，主循环放 user_app_loop()（非阻塞，自己用 HAL_GetTick 控周期）。
 * 示例：
 *   static uint32_t last;
 *   void user_app_loop(void) {
 *       uint32_t now = HAL_GetTick();
 *       if (now - last >= 10) { last = now; ... 10ms 控制周期 ... }
 *   }
 */
#include "user_app.h"
#include "main.h"

void user_app_init(void)
{
    /* TODO: 外设初始化、传感器检测、PID 参数初始化 */
}

void user_app_loop(void)
{
    /* TODO: 读传感器 → 算控制量 → 输出 PWM / 串口上报 */
}
